# Analyze-stock-using-Machine-Learning
Capture stock from Yahoo finance and analyze stock using Machine Learning Technique

We are always interesting in getting insight about stock. particularly in the Technology stocks. In this project, I will show you how to get stock information, visualize the prices of the stock, and analyze the stock by return and the risks inlvoved in your portfolio investment. 
we are also learning to predict the stock using Long Short Term Memory method

There are six element we will interest
1. Capture the change of price over time?
2. Daily return of stock 
3. Moving average of the following stocks: Apple, Microsoft, Google, Amazon
4. Correlation between the movement of the stocks price 
5. How much valur we put at risk in yor investment 
6. Predict Stock using Long Short Term Memory

